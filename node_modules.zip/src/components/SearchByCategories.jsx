function SearchByCategories(){
    return(
        <>
            <h1>Search By Categories</h1>
        </>
    );
}

export default SearchByCategories;